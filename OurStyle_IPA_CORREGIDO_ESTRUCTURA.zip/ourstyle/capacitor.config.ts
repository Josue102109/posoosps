import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.ourstyle.app",
  appName: "OurStyle",
  webDir: ".output/public",
  ios: { contentInset: "automatic" }
};

export default config;
